from enum import Enum

class TypeEnum(Enum):

    INDOOR = 0
    OUTDOOR = 1
    CITY = 2