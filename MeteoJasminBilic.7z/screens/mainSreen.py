from tkinter import ttk
import tkinter as tk
from mqtt.MqttClient import MqttClient
from screens.ValueTab import ValueTab
from screens.SimulatedTab import SimulatedTab

class MainScreen(ttk.Frame):

    SERVER_URL = "edu-agrdan.plusvps.com"

    def __init__(self, mainWindow):
        super().__init__(master=mainWindow)
        self.grid()

        self.mqtt = MqttClient(self.SERVER_URL, 1883, "meteoJB/+")
        self.mqtt.start()
        self.createMainScreen()

    def createMainScreen(self):
        self.iotPanel = ttk.LabelFrame(self, text="Main screen")
        self.iotPanel.grid(row=0, column=1, pady=5, padx=5)

        self.tabs = ttk.Notebook(self.iotPanel)
        self.tabs.grid(row=0, column=0, padx=5, pady=5)

        self.tabValue = ttk.Frame(self.tabs)
        self.tabSimulator = ttk.Frame(self.tabs)

        self.tabs.add(self.tabValue, text="Value")
        self.tabs.add(self.tabSimulator, text="Simulator")

        self.tab1 = ValueTab(self.tabValue, self.mqtt)
        self.tab2 = SimulatedTab(self.tabSimulator, self.mqtt)




